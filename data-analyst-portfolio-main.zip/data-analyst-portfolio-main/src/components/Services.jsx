export { default } from './Servicess.jsx';

